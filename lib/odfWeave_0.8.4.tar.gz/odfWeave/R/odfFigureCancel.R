odfFigureCancel <- function()
{
   .odfEnv$fig.cancel <- TRUE
   invisible(NULL)
}
